"""
Вспомогательные функции
"""
import re
from typing import Optional
from datetime import datetime


def format_duration(seconds: int) -> str:
    """Форматировать длительность в строку"""
    if not seconds:
        return "0:00"
    
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    
    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def format_views(views: int) -> str:
    """Форматировать количество просмотров"""
    if not views:
        return "0"
    
    if views >= 1_000_000:
        return f"{views / 1_000_000:.1f}M"
    elif views >= 1_000:
        return f"{views / 1_000:.1f}K"
    return str(views)


def format_file_size(size: int) -> str:
    """Форматировать размер файла"""
    if not size:
        return "Неизвестно"
    
    if size >= 1_000_000_000:
        return f"{size / 1_000_000_000:.1f} GB"
    elif size >= 1_000_000:
        return f"{size / 1_000_000:.1f} MB"
    elif size >= 1_000:
        return f"{size / 1_000:.1f} KB"
    return f"{size} B"


def format_date(date_str: str) -> str:
    """Форматировать дату в относительный формат"""
    if not date_str:
        return ""
    
    try:
        # Пробуем разные форматы даты
        for fmt in ["%Y%m%d", "%Y-%m-%d", "%d.%m.%Y"]:
            try:
                date = datetime.strptime(date_str, fmt)
                break
            except ValueError:
                continue
        else:
            return date_str
        
        now = datetime.now()
        diff_days = (now - date).days
        
        if diff_days == 0:
            return "Сегодня"
        elif diff_days == 1:
            return "Вчера"
        elif diff_days < 7:
            return f"{diff_days} дн. назад"
        elif diff_days < 30:
            return f"{diff_days // 7} нед. назад"
        elif diff_days < 365:
            return f"{diff_days // 30} мес. назад"
        return f"{diff_days // 365} г. назад"
    except Exception:
        return date_str


def extract_video_id(url: str, platform: str) -> Optional[str]:
    """Извлечь ID видео из URL"""
    patterns = {
        "youtube": [
            r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([a-zA-Z0-9_-]{11})",
        ],
        "rutube": [
            r"rutube\.ru/video/([a-zA-Z0-9]+)",
        ],
        "vimeo": [
            r"vimeo\.com/(\d+)",
        ],
    }
    
    if platform.lower() in patterns:
        for pattern in patterns[platform.lower()]:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
    
    return None


def build_video_url(video_id: str, platform: str) -> str:
    """Построить URL видео по ID и платформе"""
    urls = {
        "youtube": f"https://www.youtube.com/watch?v={video_id}",
        "rutube": f"https://rutube.ru/video/{video_id}/",
        "vimeo": f"https://vimeo.com/{video_id}",
    }
    return urls.get(platform.lower(), video_id)


def sanitize_filename(filename: str) -> str:
    """Очистить имя файла от недопустимых символов"""
    # Заменяем недопустимые символы
    invalid_chars = r'[<>:"/\\|?*]'
    return re.sub(invalid_chars, "_", filename).strip()
