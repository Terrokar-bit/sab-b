"""
Базовый класс плагина для видео-сайтов
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Callable
from models.video import (
    VideoInfo,
    ChannelInfo,
    SearchResult,
    VideoQuality,
    FormatInfo,
    SiteInfo,
)


class BasePlugin(ABC):
    """Базовый класс для всех плагинов сайтов"""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Название сайта"""
        pass
    
    @property
    @abstractmethod
    def url(self) -> str:
        """Базовый URL сайта"""
        pass
    
    @property
    @abstractmethod
    def icon(self) -> str:
        """Путь к иконке сайта"""
        pass
    
    @property
    @abstractmethod
    def color(self) -> str:
        """Цвет сайта (HEX)"""
        pass
    
    @property
    def description(self) -> str:
        """Описание сайта"""
        return ""
    
    def get_site_info(self) -> SiteInfo:
        """Получить информацию о сайте"""
        return SiteInfo(
            name=self.name,
            url=self.url,
            icon=self.icon,
            color=self.color,
            description=self.description,
        )
    
    @abstractmethod
    def get_popular(self, page: int = 1) -> SearchResult:
        """Получить популярные видео"""
        pass
    
    @abstractmethod
    def search(self, query: str, page: int = 1) -> SearchResult:
        """Поиск видео по запросу"""
        pass
    
    @abstractmethod
    def get_video(self, video_id: str) -> Optional[VideoInfo]:
        """Получить информацию о видео"""
        pass
    
    @abstractmethod
    def get_video_formats(self, video_id: str) -> List[FormatInfo]:
        """Получить доступные форматы видео"""
        pass
    
    @abstractmethod
    def get_stream_url(self, video_id: str, quality: VideoQuality) -> Optional[str]:
        """Получить URL потока видео"""
        pass
    
    @abstractmethod
    def get_similar(self, video_id: str) -> List[VideoInfo]:
        """Получить похожие видео"""
        pass
    
    @abstractmethod
    def get_channel(self, channel_id: str) -> Optional[ChannelInfo]:
        """Получить информацию о канале"""
        pass
    
    @abstractmethod
    def get_channel_videos(self, channel_id: str, page: int = 1) -> SearchResult:
        """Получить видео канала"""
        pass
    
    @abstractmethod
    def download_video(
        self,
        video_id: str,
        quality: VideoQuality,
        output_path: str,
        progress_callback: Optional[Callable[[float], None]] = None
    ) -> Optional[str]:
        """Скачать видео"""
        pass
