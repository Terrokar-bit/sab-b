"""
Загрузчик плагинов
"""
import importlib
import inspect
from pathlib import Path
from typing import List, Type
from plugins.base_plugin import BasePlugin
from plugins.plugin_registry import plugin_registry


class PluginLoader:
    """Автоматический загрузчик плагинов"""
    
    def __init__(self, plugins_dir: str = None):
        if plugins_dir is None:
            # По умолчанию ищем в plugins/sites
            self.plugins_dir = Path(__file__).parent / "sites"
        else:
            self.plugins_dir = Path(plugins_dir)
        
        self.registry = plugin_registry
    
    def discover_plugins(self) -> List[Type[BasePlugin]]:
        """Обнаружение всех плагинов в директории"""
        plugins = []
        
        if not self.plugins_dir.exists():
            print(f"[PluginLoader] Директория плагинов не найдена: {self.plugins_dir}")
            return plugins
        
        for file_path in self.plugins_dir.glob("*.py"):
            if file_path.name.startswith("_"):
                continue
            
            module_name = file_path.stem
            
            try:
                # Импортируем модуль напрямую
                module = importlib.import_module(f"plugins.sites.{module_name}")
                
                # Ищем классы-наследники BasePlugin
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    if (
                        issubclass(obj, BasePlugin) 
                        and obj is not BasePlugin 
                        and not inspect.isabstract(obj)
                    ):
                        plugins.append(obj)
                        print(f"[PluginLoader] Найден плагин: {name}")
                        
            except Exception as e:
                print(f"[PluginLoader] Ошибка загрузки плагина {module_name}: {e}")
        
        return plugins
    
    def load_all(self) -> int:
        """Загрузить и зарегистрировать все плагины"""
        plugin_classes = self.discover_plugins()
        
        for plugin_class in plugin_classes:
            try:
                plugin_instance = plugin_class()
                self.registry.register(plugin_instance)
            except Exception as e:
                print(f"[PluginLoader] Ошибка создания экземпляра плагина: {e}")
        
        print(f"[PluginLoader] Загружено {len(plugin_classes)} плагинов")
        return len(plugin_classes)
    
    def load_plugin(self, plugin_class: Type[BasePlugin]) -> bool:
        """Загрузить конкретный плагин"""
        try:
            plugin_instance = plugin_class()
            self.registry.register(plugin_instance)
            return True
        except Exception as e:
            print(f"[PluginLoader] Ошибка загрузки плагина: {e}")
            return False
