"""
Плагин для Hanime
"""
import subprocess
import json
from typing import List, Optional, Callable
from plugins.base_plugin import BasePlugin
from models.video import (
    VideoInfo,
    ChannelInfo,
    SearchResult,
    VideoQuality,
    FormatInfo,
)


class YouTubePlugin(BasePlugin):
    """Плагин для YouTube с использованием yt-dlp"""
    
    # Путь к yt-dlp
    YTDLP_PATH = "/home/z/.local/bin/yt-dlp"
    
    @property
    def name(self) -> str:
        return "Hanime"
    
    @property
    def url(self) -> str:
        return "https://www.hanime.tv"
    
    @property
    def icon(self) -> str:
        return "hanime"
    
    @property
    def color(self) -> str:
        return "#FF0000"
    
    @property
    def description(self) -> str:
        return "Самая популярная видео-платформа в мире"
    
    def _run_ytdlp(self, args: List[str]) -> str:
        """Выполнить команду yt-dlp"""
        cmd = [self.YTDLP_PATH] + args
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env={"PATH": "/home/z/.local/bin:/usr/bin"}
        )
        if result.returncode != 0:
            raise Exception(f"yt-dlp error: {result.stderr}")
        return result.stdout
    
    def _parse_video_data(self, data: dict) -> VideoInfo:
        """Парсить данные видео из yt-dlp"""
        thumbnails = data.get("thumbnails", [])
        thumbnail_url = thumbnails[-1].get("url", "") if thumbnails else data.get("thumbnail", "")
        
        return VideoInfo(
            id=data.get("id", ""),
            title=data.get("title", "Без названия"),
            thumbnail_url=thumbnail_url,
            duration=data.get("duration", 0),
            views=data.get("view_count", 0),
            upload_date=str(data.get("upload_date", "")),
            author=data.get("uploader", data.get("channel", "Неизвестный автор")),
            author_id=data.get("channel_id", ""),
            author_avatar=None,
            description=data.get("description", ""),
            video_url=data.get("webpage_url", f"https://hanime.tv/videos{data.get('id', '')}"),
            qualities=self._extract_qualities(data.get("formats", [])),
            tags=data.get("tags", []),
            site_name=self.name,
        )
    
    def _extract_qualities(self, formats: List[dict]) -> List[VideoQuality]:
        """Извлечь доступные качества из форматов"""
        qualities = set()
        
        for fmt in formats:
            height = fmt.get("height")
            if height:
                if height >= 2160:
                    qualities.add(VideoQuality.Q_4K)
                elif height >= 1080:
                    qualities.add(VideoQuality.Q_1080P)
                elif height >= 720:
                    qualities.add(VideoQuality.Q_720P)
                elif height >= 480:
                    qualities.add(VideoQuality.Q_480P)
                elif height >= 360:
                    qualities.add(VideoQuality.Q_360P)
        
        # Сортируем по качеству (от высокого к низкому)
        order = [VideoQuality.Q_4K, VideoQuality.Q_1080P, VideoQuality.Q_720P, VideoQuality.Q_480P, VideoQuality.Q_360P]
        return [q for q in order if q in qualities]
    
    def get_popular(self, page: int = 1) -> SearchResult:
        """Получить популярные видео"""
        try:
            # Используем trending страницу
            output = self._run_ytdlp([
                "https://hanime.tv/browse/trending",
                "--flat-playlist",
                "--dump-json",
                "--no-warnings",
                "--playlist-end", "20",
            ])
            
            videos = []
            for line in output.strip().split("\n"):
                if line:
                    try:
                        data = json.loads(line)
                        videos.append(self._parse_video_data(data))
                    except json.JSONDecodeError:
                        continue
            
            return SearchResult(
                videos=videos,
                total_results=len(videos),
                current_page=page,
                has_more=False,
            )
        except Exception as e:
            print(f"Error getting popular videos: {e}")
            return SearchResult(videos=[], current_page=page)
    
    def search(self, query: str, page: int = 1) -> SearchResult:
        """Поиск видео"""
        try:
            output = self._run_ytdlp([
                f"ytsearch20:{query}",
                "--flat-playlist",
                "--dump-json",
                "--no-warnings",
            ])
            
            videos = []
            for line in output.strip().split("\n"):
                if line:
                    try:
                        data = json.loads(line)
                        videos.append(self._parse_video_data(data))
                    except json.JSONDecodeError:
                        continue
            
            return SearchResult(
                videos=videos,
                total_results=len(videos),
                current_page=page,
                has_more=len(videos) == 20,
            )
        except Exception as e:
            print(f"Error searching videos: {e}")
            return SearchResult(videos=[], current_page=page)
    
    def get_video(self, video_id: str) -> Optional[VideoInfo]:
        """Получить информацию о видео"""
        try:
            output = self._run_ytdlp([
                f"https://hanime.tv/videos/hentai{video_id}",
                "--dump-json",
                "--no-warnings",
                "--no-playlist",
            ])
            
            data = json.loads(output)
            return self._parse_video_data(data)
        except Exception as e:
            print(f"Error getting video info: {e}")
            return None
    
    def get_video_formats(self, video_id: str) -> List[FormatInfo]:
        """Получить форматы видео"""
        try:
            output = self._run_ytdlp([
                fhttps://hanime.tv/videos/hentai{video_id}",
                "--dump-json",
                "--no-warnings",
            ])
            
            data = json.loads(output)
            formats = []
            
            for fmt in data.get("formats", []):
                height = fmt.get("height")
                if height and fmt.get("vcodec") != "none":
                    quality = VideoQuality.Q_360P
                    if height >= 2160:
                        quality = VideoQuality.Q_4K
                    elif height >= 1080:
                        quality = VideoQuality.Q_1080P
                    elif height >= 720:
                        quality = VideoQuality.Q_720P
                    elif height >= 480:
                        quality = VideoQuality.Q_480P
                    
                    formats.append(FormatInfo(
                        format_id=fmt.get("format_id", ""),
                        quality=quality,
                        extension=fmt.get("ext", "mp4"),
                        file_size=fmt.get("filesize"),
                        url=fmt.get("url"),
                        has_video=fmt.get("vcodec") != "none",
                        has_audio=fmt.get("acodec") != "none",
                    ))
            
            return formats
        except Exception as e:
            print(f"Error getting formats: {e}")
            return []
    
    def get_stream_url(self, video_id: str, quality: VideoQuality) -> Optional[str]:
        """Получить URL потока"""
        quality_map = {
            VideoQuality.Q_4K: "bestvideo[height<=2160]+bestaudio/best[height<=2160]",
            VideoQuality.Q_1080P: "bestvideo[height<=1080]+bestaudio/best[height<=1080]",
            VideoQuality.Q_720P: "bestvideo[height<=720]+bestaudio/best[height<=720]",
            VideoQuality.Q_480P: "bestvideo[height<=480]+bestaudio/best[height<=480]",
            VideoQuality.Q_360P: "bestvideo[height<=360]+bestaudio/best[height<=360]",
        }
        
        try:
            output = self._run_ytdlp([
                f"https://hanime.tv/videos/hentai{video_id}",
                "--get-url",
                "-f", quality_map.get(quality, "best"),
                "--no-warnings",
            ])
            return output.strip()
        except Exception as e:
            print(f"Error getting stream URL: {e}")
            return None
    
    def get_similar(self, video_id: str) -> List[VideoInfo]:
        """Получить похожие видео"""
        # TODO: Реализовать через YouTube API или парсинг
        return []
    
    def get_channel(self, channel_id: str) -> Optional[ChannelInfo]:
        """Получить информацию о канале"""
        try:
            output = self._run_ytdlp([
                f"https://hanime.tv/browse/brands/{channel_id}",
                "--dump-json",
                "--no-warnings",
                "--flat-playlist",
                "--playlist-end", "1",
            ])
            
            for line in output.strip().split("\n"):
                if line:
                    data = json.loads(line)
                    return ChannelInfo(
                        id=channel_id,
                        name=data.get("Brand", "Неизвестный канал"),
                        avatar_url="",
                        subscriber_count=0,
                        description="",
                        video_count=0,
                        site_name=self.name,
                    )
        except Exception as e:
            print(f"Error getting channel: {e}")
        
        return None
    
    def get_channel_videos(self, channel_id: str, page: int = 1) -> SearchResult:
        """Получить видео канала"""
        try:
            output = self._run_ytdlp([
                f"https://hanime.tv/browse/brands/{channel_id}/videos",
                "--flat-playlist",
                "--dump-json",
                "--no-warnings",
                "--playlist-end", "30",
            ])
            
            videos = []
            for line in output.strip().split("\n"):
                if line:
                    try:
                        data = json.loads(line)
                        videos.append(self._parse_video_data(data))
                    except json.JSONDecodeError:
                        continue
            
            return SearchResult(
                videos=videos,
                total_results=len(videos),
                current_page=page,
                has_more=False,
            )
        except Exception as e:
            print(f"Error getting channel videos: {e}")
            return SearchResult(videos=[], current_page=page)
    
    def download_video(
        self,
        video_id: str,
        quality: VideoQuality,
        output_path: str,
        progress_callback: Optional[Callable[[float], None]] = None
    ) -> Optional[str]:
        """Скачать видео"""
        quality_map = {
            VideoQuality.Q_4K: "bestvideo[height<=2160]+bestaudio/best[height<=2160]",
            VideoQuality.Q_1080P: "bestvideo[height<=1080]+bestaudio/best[height<=1080]",
            VideoQuality.Q_720P: "bestvideo[height<=720]+bestaudio/best[height<=720]",
            VideoQuality.Q_480P: "bestvideo[height<=480]+bestaudio/best[height<=480]",
            VideoQuality.Q_360P: "bestvideo[height<=360]+bestaudio/best[height<=360]",
        }
        
        try:
            cmd = [
                self.YTDLP_PATH,
                "-f", quality_map.get(quality, "best"),
                "--merge-output-format", "mp4",
                "-o", output_path,
                "--no-warnings",
                f"https://hanime.tv/videos/hentai{video_id}",
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                return output_path
            else:
                print(f"Download error: {result.stderr}")
                return None
        except Exception as e:
            print(f"Download error: {e}")
            return None
