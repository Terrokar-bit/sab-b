"""
Реестр плагинов
"""
from typing import Dict, List, Optional
from plugins.base_plugin import BasePlugin
from models.video import SiteInfo


class PluginRegistry:
    """Реестр всех загруженных плагинов"""
    
    def __init__(self):
        self._plugins: Dict[str, BasePlugin] = {}
    
    def register(self, plugin: BasePlugin) -> None:
        """Зарегистрировать плагин"""
        if plugin.name in self._plugins:
            print(f"[PluginRegistry] Плагин '{plugin.name}' уже зарегистрирован. Перезапись.")
        self._plugins[plugin.name] = plugin
        print(f"[PluginRegistry] Зарегистрирован плагин: {plugin.name}")
    
    def unregister(self, name: str) -> bool:
        """Удалить плагин из реестра"""
        if name in self._plugins:
            del self._plugins[name]
            return True
        return False
    
    def get(self, name: str) -> Optional[BasePlugin]:
        """Получить плагин по имени"""
        return self._plugins.get(name)
    
    def has(self, name: str) -> bool:
        """Проверить наличие плагина"""
        return name in self._plugins
    
    def get_all(self) -> List[BasePlugin]:
        """Получить все плагины"""
        return list(self._plugins.values())
    
    def get_names(self) -> List[str]:
        """Получить имена всех плагинов"""
        return list(self._plugins.keys())
    
    def get_sites_info(self) -> List[SiteInfo]:
        """Получить информацию о всех сайтах"""
        return [plugin.get_site_info() for plugin in self._plugins.values()]
    
    @property
    def count(self) -> int:
        """Количество зарегистрированных плагинов"""
        return len(self._plugins)


# Глобальный экземпляр реестра
plugin_registry = PluginRegistry()
