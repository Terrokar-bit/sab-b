"""
Система плагинов
"""
from .base_plugin import BasePlugin
from .plugin_registry import PluginRegistry, plugin_registry
from .plugin_loader import PluginLoader

__all__ = [
    "BasePlugin",
    "PluginRegistry",
    "plugin_registry",
    "PluginLoader",
]
