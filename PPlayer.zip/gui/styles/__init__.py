"""
Стили GUI
"""
from pathlib import Path

STYLES_DIR = Path(__file__).parent

def load_stylesheet(name: str = "main.qss") -> str:
    """Загрузить таблицу стилей"""
    style_path = STYLES_DIR / name
    if style_path.exists():
        with open(style_path, "r", encoding="utf-8") as f:
            return f.read()
    return ""
