"""
Главное окно приложения
"""
from typing import Optional
from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QStackedWidget,
    QLabel,
    QPushButton,
    QComboBox,
    QLineEdit,
    QScrollArea,
    QFrame,
    QGridLayout,
    QMessageBox,
)
from PyQt6.QtCore import Qt, pyqtSignal, QSize
from PyQt6.QtGui import QIcon, QAction

from config import config
from models.video import VideoInfo, SiteInfo
from utils.logger import logger
from gui.styles import load_stylesheet


class MainWindow(QMainWindow):
    """Главное окно приложения"""
    
    def __init__(self, app):
        super().__init__()
        self._app = app
        
        # Состояние
        self._current_site: Optional[str] = None
        self._current_video: Optional[VideoInfo] = None
        self._videos: list = []
        
        # Настройка окна
        self._setup_ui()
        self._load_style()
        self._load_sites()
        
        logger.info("Главное окно создано")
    
    def _setup_ui(self) -> None:
        """Настроить UI"""
        # Основные параметры окна
        self.setWindowTitle(config.app_name)
        self.setMinimumSize(config.window_width, config.window_height)
        self.resize(config.window_width, config.window_height)
        
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Главный layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Header
        self._setup_header(main_layout)
        
        # Content area (StackedWidget для переключения между страницами)
        self.content_stack = QStackedWidget()
        main_layout.addWidget(self.content_stack, 1)
        
        # Создаем страницы
        self._setup_home_page()
        self._setup_video_page()
        
        # Footer
        self._setup_footer(main_layout)
    
    def _setup_header(self, parent_layout: QVBoxLayout) -> None:
        """Настроить заголовок"""
        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(60)
        header.setStyleSheet("""
            QFrame#header {
                background-color: #1a1a1a;
                border-bottom: 1px solid #2a2a2a;
            }
        """)
        
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(16, 8, 16, 8)
        header_layout.setSpacing(12)
        
        # Кнопка "Назад"
        self.back_button = QPushButton("←")
        self.back_button.setFixedSize(40, 40)
        self.back_button.clicked.connect(self._on_back_clicked)
        self.back_button.setVisible(False)
        header_layout.addWidget(self.back_button)
        
        # Логотип
        logo_label = QLabel("🎬")
        logo_label.setStyleSheet("font-size: 24px;")
        header_layout.addWidget(logo_label)
        
        title_label = QLabel(config.app_name)
        title_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        header_layout.addWidget(title_label)
        
        header_layout.addSpacing(20)
        
        # Выбор сайта
        self.site_combo = QComboBox()
        self.site_combo.setFixedWidth(150)
        self.site_combo.currentTextChanged.connect(self._on_site_changed)
        header_layout.addWidget(self.site_combo)
        
        header_layout.addSpacing(10)
        
        # Поиск
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск видео...")
        self.search_input.setMinimumWidth(300)
        self.search_input.returnPressed.connect(self._on_search)
        header_layout.addWidget(self.search_input, 1)
        
        # Кнопка поиска
        self.search_button = QPushButton("🔍")
        self.search_button.setFixedSize(40, 40)
        self.search_button.clicked.connect(self._on_search)
        header_layout.addWidget(self.search_button)
        
        header_layout.addSpacing(10)
        
        # Кнопка загрузок
        downloads_button = QPushButton("⬇")
        downloads_button.setFixedSize(40, 40)
        header_layout.addWidget(downloads_button)
        
        parent_layout.addWidget(header)
    
    def _setup_home_page(self) -> None:
        """Настроить домашнюю страницу"""
        home_widget = QWidget()
        home_layout = QVBoxLayout(home_widget)
        home_layout.setContentsMargins(16, 16, 16, 16)
        
        # Заголовок секции
        self.section_title = QLabel("Популярное видео")
        self.section_title.setStyleSheet("font-size: 20px; font-weight: bold;")
        home_layout.addWidget(self.section_title)
        
        # Область с видео (ScrollArea)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        # Контейнер для видео
        self.videos_container = QWidget()
        self.videos_layout = QGridLayout(self.videos_container)
        self.videos_layout.setSpacing(16)
        self.videos_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        
        scroll.setWidget(self.videos_container)
        home_layout.addWidget(scroll, 1)
        
        # Кнопка "Загрузить ещё"
        self.load_more_button = QPushButton("Загрузить ещё")
        self.load_more_button.clicked.connect(self._on_load_more)
        home_layout.addWidget(self.load_more_button, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.content_stack.addWidget(home_widget)
    
    def _setup_video_page(self) -> None:
        """Настроить страницу просмотра видео"""
        video_widget = QWidget()
        video_layout = QVBoxLayout(video_widget)
        video_layout.setContentsMargins(16, 16, 16, 16)
        
        # Здесь будет видео плеер и информация
        self.video_title = QLabel("Название видео")
        self.video_title.setStyleSheet("font-size: 20px; font-weight: bold;")
        self.video_title.setWordWrap(True)
        video_layout.addWidget(self.video_title)
        
        # Информация о видео
        info_layout = QHBoxLayout()
        self.video_views = QLabel("0 просмотров")
        self.video_views.setStyleSheet("color: #aaaaaa;")
        info_layout.addWidget(self.video_views)
        
        self.video_date = QLabel("")
        self.video_date.setStyleSheet("color: #aaaaaa;")
        info_layout.addWidget(self.video_date)
        info_layout.addStretch()
        video_layout.addLayout(info_layout)
        
        # Автор
        author_frame = QFrame()
        author_frame.setStyleSheet("""
            QFrame {
                background-color: #1a1a1a;
                border-radius: 8px;
                padding: 8px;
            }
        """)
        author_layout = QHBoxLayout(author_frame)
        
        self.author_avatar = QLabel("👤")
        self.author_avatar.setStyleSheet("font-size: 24px;")
        author_layout.addWidget(self.author_avatar)
        
        author_info = QVBoxLayout()
        self.author_name = QLabel("Автор")
        self.author_name.setStyleSheet("font-weight: bold;")
        author_info.addWidget(self.author_name)
        
        self.author_label = QLabel("Автор")
        self.author_label.setStyleSheet("color: #aaaaaa; font-size: 12px;")
        author_info.addWidget(self.author_label)
        author_layout.addLayout(author_info)
        author_layout.addStretch()
        
        video_layout.addWidget(author_frame)
        
        # Описание
        self.video_description = QLabel("")
        self.video_description.setStyleSheet("color: #cccccc;")
        self.video_description.setWordWrap(True)
        video_layout.addWidget(self.video_description)
        
        video_layout.addStretch()
        
        self.content_stack.addWidget(video_widget)
    
    def _setup_footer(self, parent_layout: QVBoxLayout) -> None:
        """Настроить подвал"""
        footer = QFrame()
        footer.setStyleSheet("""
            QFrame {
                background-color: #1a1a1a;
                border-top: 1px solid #2a2a2a;
            }
        """)
        footer.setFixedHeight(40)
        
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(16, 8, 16, 8)
        
        footer_label = QLabel(f"{config.app_name} v{config.app_version}")
        footer_label.setStyleSheet("color: #666666;")
        footer_layout.addWidget(footer_label)
        
        footer_layout.addStretch()
        
        sites_label = QLabel("Поддерживаемые сайты: YouTube, Rutube, Vimeo")
        sites_label.setStyleSheet("color: #666666;")
        footer_layout.addWidget(sites_label)
        
        parent_layout.addWidget(footer)
    
    def _load_style(self) -> None:
        """Загрузить стили"""
        stylesheet = load_stylesheet("main.qss")
        if stylesheet:
            self.setStyleSheet(stylesheet)
    
    def _load_sites(self) -> None:
        """Загрузить список сайтов"""
        sites = self._app.get_sites_info()
        
        self.site_combo.clear()
        for site in sites:
            self.site_combo.addItem(site.name)
        
        if sites:
            self._current_site = sites[0].name
    
    def _on_back_clicked(self) -> None:
        """Обработчик кнопки "Назад" """
        self.content_stack.setCurrentIndex(0)
        self.back_button.setVisible(False)
        self._current_video = None
    
    def _on_site_changed(self, site_name: str) -> None:
        """Обработчик смены сайта"""
        if site_name:
            self._current_site = site_name
            self._load_popular_videos()
    
    def _on_search(self) -> None:
        """Обработчик поиска"""
        query = self.search_input.text().strip()
        if query and self._current_site:
            self._search_videos(query)
    
    def _on_load_more(self) -> None:
        """Обработчик загрузки ещё"""
        # TODO: Реализовать пагинацию
        pass
    
    def _load_popular_videos(self) -> None:
        """Загрузить популярные видео"""
        if not self._current_site:
            return
        
        plugin = self._app.get_plugin(self._current_site)
        if not plugin:
            return
        
        try:
            self.section_title.setText(f"Популярное на {self._current_site}")
            result = plugin.get_popular()
            self._videos = result.videos
            self._display_videos()
        except Exception as e:
            logger.error(f"Ошибка загрузки видео: {e}")
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить видео: {e}")
    
    def _search_videos(self, query: str) -> None:
        """Поиск видео"""
        if not self._current_site:
            return
        
        plugin = self._app.get_plugin(self._current_site)
        if not plugin:
            return
        
        try:
            self.section_title.setText(f'Результаты поиска: "{query}"')
            result = plugin.search(query)
            self._videos = result.videos
            self._display_videos()
        except Exception as e:
            logger.error(f"Ошибка поиска: {e}")
            QMessageBox.warning(self, "Ошибка", f"Не удалось выполнить поиск: {e}")
    
    def _display_videos(self) -> None:
        """Отобразить видео в сетке"""
        # Очищаем текущий layout
        while self.videos_layout.count():
            item = self.videos_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Добавляем видео
        columns = 4
        for i, video in enumerate(self._videos):
            row = i // columns
            col = i % columns
            
            card = self._create_video_card(video)
            self.videos_layout.addWidget(card, row, col)
    
    def _create_video_card(self, video: VideoInfo) -> QFrame:
        """Создать карточку видео"""
        card = QFrame()
        card.setObjectName("videoCard")
        card.setFixedSize(280, 220)
        card.setCursor(Qt.CursorShape.PointingHandCursor)
        card.mousePressEvent = lambda e, v=video: self._on_video_clicked(v)
        
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(0, 0, 0, 8)
        card_layout.setSpacing(8)
        
        # Превью (placeholder)
        preview = QLabel()
        preview.setFixedSize(280, 160)
        preview.setStyleSheet("""
            QLabel {
                background-color: #2a2a2a;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            }
        """)
        preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        preview.setText("🎬")
        preview.setStyleSheet(preview.styleSheet() + "font-size: 40px;")
        card_layout.addWidget(preview)
        
        # Название
        title = QLabel(video.title[:50] + "..." if len(video.title) > 50 else video.title)
        title.setWordWrap(True)
        title.setStyleSheet("font-weight: bold; padding: 0 8px;")
        card_layout.addWidget(title)
        
        # Информация
        info = QLabel(f"{video.author} • {video.get_views_str()} просмотров")
        info.setStyleSheet("color: #aaaaaa; font-size: 11px; padding: 0 8px;")
        card_layout.addWidget(info)
        
        return card
    
    def _on_video_clicked(self, video: VideoInfo) -> None:
        """Обработчик клика на видео"""
        self._current_video = video
        
        # Обновляем страницу видео
        self.video_title.setText(video.title)
        self.video_views.setText(f"{video.views:,} просмотров".replace(",", " "))
        self.video_date.setText(video.get_date_str())
        self.author_name.setText(video.author)
        self.video_description.setText(video.description[:500] + "..." if len(video.description) > 500 else video.description)
        
        # Переключаемся на страницу видео
        self.content_stack.setCurrentIndex(1)
        self.back_button.setVisible(True)
