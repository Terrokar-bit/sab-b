"""
HTTP клиент для сетевых запросов
"""
import httpx
from typing import Optional, Dict, Any
from config import config
from utils.logger import logger


class HttpClient:
    """Асинхронный HTTP клиент"""
    
    def __init__(self, timeout: int = None):
        self._timeout = timeout or config.request_timeout
        self._client: Optional[httpx.AsyncClient] = None
    
    async def __aenter__(self):
        self._client = httpx.AsyncClient(timeout=self._timeout)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._client:
            await self._client.aclose()
    
    async def get(
        self,
        url: str,
        params: Dict[str, Any] = None,
        headers: Dict[str, str] = None
    ) -> httpx.Response:
        """Выполнить GET запрос"""
        logger.debug(f"GET {url}")
        
        try:
            response = await self._client.get(url, params=params, headers=headers)
            response.raise_for_status()
            return response
        except httpx.HTTPError as e:
            logger.error(f"HTTP GET ошибка: {e}")
            raise
    
    async def post(
        self,
        url: str,
        data: Dict[str, Any] = None,
        json: Dict[str, Any] = None,
        headers: Dict[str, str] = None
    ) -> httpx.Response:
        """Выполнить POST запрос"""
        logger.debug(f"POST {url}")
        
        try:
            response = await self._client.post(url, data=data, json=json, headers=headers)
            response.raise_for_status()
            return response
        except httpx.HTTPError as e:
            logger.error(f"HTTP POST ошибка: {e}")
            raise
    
    async def download(
        self,
        url: str,
        output_path: str,
        chunk_size: int = 8192
    ) -> str:
        """Скачать файл"""
        logger.debug(f"Downloading {url} to {output_path}")
        
        try:
            async with self._client.stream("GET", url) as response:
                response.raise_for_status()
                
                with open(output_path, "wb") as f:
                    async for chunk in response.aiter_bytes(chunk_size):
                        f.write(chunk)
            
            return output_path
        except Exception as e:
            logger.error(f"Download error: {e}")
            raise


# Синхронный клиент для простых операций
class SyncHttpClient:
    """Синхронный HTTP клиент"""
    
    def __init__(self, timeout: int = None):
        self._timeout = timeout or config.request_timeout
    
    def get(
        self,
        url: str,
        params: Dict[str, Any] = None,
        headers: Dict[str, str] = None
    ) -> httpx.Response:
        """Выполнить GET запрос"""
        with httpx.Client(timeout=self._timeout) as client:
            response = client.get(url, params=params, headers=headers)
            response.raise_for_status()
            return response
    
    def post(
        self,
        url: str,
        data: Dict[str, Any] = None,
        json: Dict[str, Any] = None,
        headers: Dict[str, str] = None
    ) -> httpx.Response:
        """Выполнить POST запрос"""
        with httpx.Client(timeout=self._timeout) as client:
            response = client.post(url, data=data, json=json, headers=headers)
            response.raise_for_status()
            return response
