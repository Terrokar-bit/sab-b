"""
Сетевой слой
"""
from .http_client import HttpClient, SyncHttpClient

__all__ = ["HttpClient", "SyncHttpClient"]
