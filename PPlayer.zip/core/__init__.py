"""
Ядро приложения
"""
from .app import VideoAggregatorApp

__all__ = ["VideoAggregatorApp"]
