"""
Класс приложения
"""
import sys
from typing import Optional
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QObject, pyqtSignal

from config import config
from plugins.plugin_loader import PluginLoader
from plugins.plugin_registry import plugin_registry
from utils.logger import logger


class VideoAggregatorApp(QObject):
    """Главный класс приложения"""
    
    # Сигналы
    plugins_loaded = pyqtSignal(int)  # Количество загруженных плагинов
    
    def __init__(self):
        super().__init__()
        self._qt_app: Optional[QApplication] = None
        self._main_window = None
        self._plugin_loader: Optional[PluginLoader] = None
        
        logger.info(f"Инициализация {config.app_name} v{config.app_version}")
    
    def initialize(self, argv: list = None) -> bool:
        """Инициализировать приложение"""
        if argv is None:
            argv = sys.argv
        
        try:
            # Создаем Qt приложение
            self._qt_app = QApplication(argv)
            self._qt_app.setApplicationName(config.app_name)
            self._qt_app.setApplicationVersion(config.app_version)
            
            # Загружаем плагины
            self._load_plugins()
            
            logger.info("Приложение успешно инициализировано")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка инициализации приложения: {e}")
            return False
    
    def _load_plugins(self) -> None:
        """Загрузить плагины"""
        self._plugin_loader = PluginLoader()
        count = self._plugin_loader.load_all()
        self.plugins_loaded.emit(count)
    
    def get_plugin(self, name: str):
        """Получить плагин по имени"""
        return plugin_registry.get(name)
    
    def get_all_plugins(self) -> list:
        """Получить все плагины"""
        return plugin_registry.get_all()
    
    def get_sites_info(self) -> list:
        """Получить информацию о всех сайтах"""
        return plugin_registry.get_sites_info()
    
    def run(self) -> int:
        """Запустить приложение"""
        if not self._qt_app:
            logger.error("Приложение не инициализировано")
            return 1
        
        # Импортируем здесь, чтобы избежать циклических импортов
        from gui.main_window import MainWindow
        
        # Создаем главное окно
        self._main_window = MainWindow(self)
        self._main_window.show()
        
        logger.info("Приложение запущено")
        return self._qt_app.exec()
    
    def quit(self) -> None:
        """Закрыть приложение"""
        if self._qt_app:
            self._qt_app.quit()
            logger.info("Приложение закрыто")
