#!/usr/bin/env python3
"""
Video Aggregator - Единый интерфейс для работы с видео-хостингами

Точка входа в приложение
"""
import sys
from pathlib import Path

# Добавляем корневую директорию в путь для импортов
sys.path.insert(0, str(Path(__file__).parent))

from core.app import VideoAggregatorApp
from utils.logger import logger


def main():
    """Главная функция"""
    app = VideoAggregatorApp()
    
    if not app.initialize(sys.argv):
        logger.error("Не удалось инициализировать приложение")
        return 1
    
    return app.run()


if __name__ == "__main__":
    sys.exit(main())
