"""
Модели данных для видео агрегатора
"""
from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum
from datetime import datetime


class VideoQuality(Enum):
    """Качество видео"""
    Q_360P = "360p"
    Q_480P = "480p"
    Q_720P = "720p"
    Q_1080P = "1080p"
    Q_4K = "4k"


@dataclass
class VideoInfo:
    """Модель информации о видео"""
    id: str
    title: str
    thumbnail_url: str
    duration: int  # в секундах
    views: int
    upload_date: str
    author: str
    author_id: str
    author_avatar: Optional[str] = None
    description: str = ""
    video_url: str = ""
    qualities: List[VideoQuality] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    site_name: str = ""
    preview_url: Optional[str] = None  # URL для превью при наведении
    
    def get_duration_str(self) -> str:
        """Получить строковое представление длительности"""
        duration = int(self.duration) if self.duration else 0
        hours = duration // 3600
        minutes = (duration % 3600) // 60
        seconds = duration % 60
        
        if hours > 0:
            return f"{hours}:{minutes:02d}:{seconds:02d}"
        return f"{minutes}:{seconds:02d}"
    
    def get_views_str(self) -> str:
        """Получить строковое представление просмотров"""
        if self.views >= 1_000_000:
            return f"{self.views / 1_000_000:.1f}M"
        elif self.views >= 1_000:
            return f"{self.views / 1_000:.1f}K"
        return str(self.views)
    
    def get_date_str(self) -> str:
        """Получить строковое представление даты"""
        try:
            # Пробуем разные форматы даты
            for fmt in ["%Y%m%d", "%Y-%m-%d", "%d.%m.%Y"]:
                try:
                    date = datetime.strptime(self.upload_date, fmt)
                    break
                except ValueError:
                    continue
            else:
                return self.upload_date
            
            now = datetime.now()
            diff_days = (now - date).days
            
            if diff_days == 0:
                return "Сегодня"
            elif diff_days == 1:
                return "Вчера"
            elif diff_days < 7:
                return f"{diff_days} дн. назад"
            elif diff_days < 30:
                return f"{diff_days // 7} нед. назад"
            elif diff_days < 365:
                return f"{diff_days // 30} мес. назад"
            return f"{diff_days // 365} г. назад"
        except Exception:
            return self.upload_date


@dataclass
class ChannelInfo:
    """Модель информации о канале"""
    id: str
    name: str
    avatar_url: str
    subscriber_count: int
    description: str
    video_count: int
    site_name: str = ""
    
    def get_subscribers_str(self) -> str:
        """Получить строковое представление подписчиков"""
        if self.subscriber_count >= 1_000_000:
            return f"{self.subscriber_count / 1_000_000:.1f}M"
        elif self.subscriber_count >= 1_000:
            return f"{self.subscriber_count / 1_000:.1f}K"
        return str(self.subscriber_count)


@dataclass
class SearchResult:
    """Результат поиска"""
    videos: List[VideoInfo]
    total_results: int = 0
    current_page: int = 1
    has_more: bool = False


@dataclass
class FormatInfo:
    """Информация о формате видео"""
    format_id: str
    quality: VideoQuality
    extension: str
    file_size: Optional[int] = None
    url: Optional[str] = None
    has_video: bool = True
    has_audio: bool = True
    
    def get_size_str(self) -> str:
        """Получить строковое представление размера"""
        if not self.file_size:
            return "Неизвестно"
        
        size = self.file_size
        if size >= 1_000_000_000:
            return f"{size / 1_000_000_000:.1f} GB"
        elif size >= 1_000_000:
            return f"{size / 1_000_000:.1f} MB"
        elif size >= 1_000:
            return f"{size / 1_000:.1f} KB"
        return f"{size} B"


@dataclass
class SiteInfo:
    """Информация о сайте/платформе"""
    name: str
    url: str
    icon: str
    color: str
    description: str = ""
