"""
Модели данных
"""
from .video import (
    VideoQuality,
    VideoInfo,
    ChannelInfo,
    SearchResult,
    FormatInfo,
    SiteInfo,
)

__all__ = [
    "VideoQuality",
    "VideoInfo",
    "ChannelInfo",
    "SearchResult",
    "FormatInfo",
    "SiteInfo",
]
