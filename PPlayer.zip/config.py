"""
Конфигурация приложения Video Aggregator
"""
import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import List


# Базовые пути
BASE_DIR = Path(__file__).parent.absolute()
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
DOWNLOADS_DIR = DATA_DIR / "downloads"

# Создаем директории если не существуют
for directory in [DATA_DIR, CACHE_DIR, DOWNLOADS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)


@dataclass
class AppConfig:
    """Конфигурация приложения"""
    
    # Основные настройки
    app_name: str = "Video Aggregator"
    app_version: str = "1.0.0"
    
    # Пути
    base_dir: Path = field(default_factory=lambda: BASE_DIR)
    data_dir: Path = field(default_factory=lambda: DATA_DIR)
    cache_dir: Path = field(default_factory=lambda: CACHE_DIR)
    downloads_dir: Path = field(default_factory=lambda: DOWNLOADS_DIR)
    
    # Файлы
    cache_db: str = "cache.db"
    settings_file: str = "settings.json"
    
    # Сеть
    request_timeout: int = 30
    max_retries: int = 3
    
    # UI
    window_width: int = 1280
    window_height: int = 720
    videos_per_page: int = 20
    
    # Качество по умолчанию
    default_quality: str = "720p"
    
    @property
    def cache_db_path(self) -> Path:
        return self.data_dir / self.cache_db
    
    @property
    def settings_path(self) -> Path:
        return self.data_dir / self.settings_file


# Глобальный экземпляр конфигурации
config = AppConfig()


# Поддерживаемые качества видео
VIDEO_QUALITIES = [
    "4k",
    "1080p",
    "720p",
    "480p",
    "360p",
]

# Форматы для скачивания
DOWNLOAD_FORMATS = {
    "mp4": "MPEG-4 Video",
    "webm": "WebM Video",
    "mp3": "MP3 Audio",
}
