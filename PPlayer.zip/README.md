# Video Aggregator

Десктопное приложение на Python для агрегации видеоконтента с различных видео-хостингов.

## Возможности

- **Единый интерфейс** для работы с множеством видео-хостингов
- **Модульная архитектура** — легкое добавление новых сайтов через плагины
- **Поиск видео** — поиск по названию на выбранном сайте
- **Просмотр видео** — встроенный видео плеер
- **Скачивание видео** — с выбором качества

## Требования

- Python 3.10+
- PyQt6
- yt-dlp

## Установка

```bash
# Клонируйте или скачайте проект
cd video_aggregator

# Установите зависимости
pip install -r requirements.txt

# Установите yt-dlp (если не установлен)
pip install yt-dlp
```

## Запуск

```bash
cd video_aggregator
python main.py
```

## Структура проекта

```
video_aggregator/
├── main.py                 # Точка входа
├── config.py               # Конфигурация приложения
├── requirements.txt        # Зависимости
│
├── core/                   # Ядро приложения
│   └── app.py              # Класс приложения
│
├── gui/                    # Графический интерфейс
│   ├── main_window.py      # Главное окно
│   └── styles/             # Стили QSS
│
├── plugins/                # Система плагинов
│   ├── base_plugin.py      # Базовый класс плагина
│   ├── plugin_registry.py  # Реестр плагинов
│   ├── plugin_loader.py    # Загрузчик плагинов
│   └── sites/              # Плагины сайтов
│       └── youtube.py      # YouTube плагин
│
├── models/                 # Модели данных
│   └── video.py            # VideoInfo, ChannelInfo, etc.
│
├── network/                # Сетевой слой
│   └── http_client.py      # HTTP клиент
│
├── utils/                  # Утилиты
│   ├── logger.py           # Логирование
│   └── helpers.py          # Вспомогательные функции
│
└── data/                   # Данные приложения
    ├── cache/              # Кэш
    └── downloads/          # Скачанные файлы
```

## Добавление нового плагина

Для добавления поддержки нового сайта:

1. Создайте файл `plugins/sites/newsite.py`
2. Унаследуйте класс от `BasePlugin`
3. Реализуйте все абстрактные методы

Пример:

```python
# plugins/sites/newsite.py
from plugins.base_plugin import BasePlugin
from models.video import VideoInfo, SearchResult, VideoQuality

class NewSitePlugin(BasePlugin):
    
    @property
    def name(self) -> str:
        return "NewSite"
    
    @property
    def url(self) -> str:
        return "https://newsite.com"
    
    @property
    def icon(self) -> str:
        return "newsite"
    
    @property
    def color(self) -> str:
        return "#FF0000"
    
    def search(self, query: str, page: int = 1) -> SearchResult:
        # Реализуйте поиск
        pass
    
    # ... остальные методы
```

Плагин будет автоматически загружен при запуске приложения.

## Поддерживаемые платформы

- YouTube (реализован)
- Rutube (в разработке)
- Vimeo (в разработке)

## Технологии

- **GUI:** PyQt6
- **Видео:** yt-dlp (1000+ сайтов)
- **HTTP:** httpx
- **Парсинг:** BeautifulSoup4 + lxml

## Лицензия

MIT License
